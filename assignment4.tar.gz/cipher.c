/*
Program to implement a t e x t c i p h e r
***************************************************************
* Author Dept . Date Notes
***************************************************************
* Doris Lu Wang  Comp. Science. Mar 14 2021 Started on the Question.
* Doris Lu Wang  Comp. Science. Mar 14 2021 
*/
#include <stdio.h>

int main(int argc, char *argv[])
{   
    // Check if the program is passed three arguments
    if (argc != 4)
    {
        printf("Usage: ./cipher [-e|-d] <key> <MESSAGE>\n");
        return 1;
    }
    
    // Checks that the first argument is valid
    if (!(argv[1][0] == '-' && argv[1][1] == 'e' && argv[1][2]=='\0') &&
        !(argv[1][0] == '-' && argv[1][1] == 'd' && argv[1][2]=='\0'))
    {
        printf("Error %s is not a valid option\n", argv[1]);
        return 1;
    }
    
    // Checks valid second argument
    if ( !(argv[2][0] >= '2' && argv[2][0] <= '9' && argv[2][1]==0) && 
         !(argv[2][0]=='1' && argv[2][1]=='0' && argv[2][2]==0) ) {
            printf("Error %s is not a valid key\n", argv[2]);
            return 1;
    }

    // Only encode when ecode option is selected. Does nothing for decoding
    if (argv[1][0] == '-' && argv[1][1] == 'e' && argv[1][2]=='\0') {
        int n = 0;
        while (argv[3][n] != '\0'){
            ++n;
        }
        int r = 0;
        if (argv[2][0] != '1'){
            r = argv[2][0] - '0';
        }
        else {
            r = 10;
        }
        
        int c = 2 * r - 2;
        
        for (int i = 0; i < r; i++) {
            for (int j = 0; j + i < n; j += c) {
                putchar(argv[3][j + i]);
                if (i != 0 && i != r - 1 && j + c - i < n)
                    putchar(argv[3][j + c - i]);
            }
        }
    }
    putchar('\n');
    return 0;
}
