#!/bin/bash

gcc -o cipher cipher.c

# test incorrect number of arguments
./cipher asdf

echo $?

# test incorrect first argument
./cipher -asdf qwer zxcv

echo $?

# test incorrect second argument
./cipher -e asdf zxcv

echo $?

# test incorrect second argument
./cipher -e 4.r zxcv

echo $?

# test decryption (does  nothing)
./cipher -d 10 THISISASECRETMESSAGE

echo $?

# test working examples
./cipher -e 10 THISISASECRETMESSAGE
./cipher -e 3 THISISASECRETMESSAGE
