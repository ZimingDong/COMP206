#!/bin/bash

#Check if the number of the arguments is right.
if [[ $# -ne 1 ]]
then
	echo Usage: $0 sensorlogdir
	exit 1
#Check is the passed argument is a valid directory name.
elif [[ ! -d $1 ]]
then
	echo Error! $1 is not a valid directory name 
	exit 1
fi

#Use the command "find" to  look for files starting under the given directory hierarchy. 
#For loop can make sure all the files that mathes the specific file name pattern mentioned in the assignment will be looked for.
for file in $(find $1 -name "sensordata-*.log")
do
	echo Processing sensor data set for $file
	echo Year,Month,Day,Hour,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5
#The gsub function causes the substitution to occur when all the regular expressions are matched.
#Check for errors and print the sensors by the correct orders. 	
	awk '/readouts/{OFS=","; gsub("-", ",", $1); 
	if ($5 != "ERROR") { arg1=$5 }
	if ($6 != "ERROR") { arg2=$6 }
	if ($7 != "ERROR") { arg3=$7 }
	if ($8 != "ERROR") { arg4=$8 }
	if ($9 != "ERROR") { arg5=$9 }
	{ gsub("-", ",", $1); print $1, substr($2, 1, 2), arg1, arg2, arg3, arg4, arg5 } }' $file
	echo ====================================
done

for file in $(find $1 -name "sensordata-*.log")
do
	echo Readout statistics
	echo Year,Month,Hour,MaxTemp,MaxSensor,MinTemp,MinSensor
#Ignore the data of error when we are comparing the min and the max one. Also use a for loop inside of the command "awk" to complete the data comparison.
	awk '/readouts/{OFS=","; min=100; min_idx=1; max=-100; max_idx=1
	for(i=5; i<=NF; i++){
		if ( $i!="ERROR" && $i<min ) {
			min=$i
			min_idx=i-4
		} 
		if ( $i!="ERROR" && $i>max ) {
			max=$i
			max_idx=i-4
		}
	};
	{gsub("-", ",", $1); print $1, substr($2, 1, 2), max, "Sensor"max_idx,  min, "Sensor"min_idx}
	}
	' $file
	echo ====================================
done

echo Sensor error statistics
echo Year,Month,Day,Sensor1,Sensor2,Sensor3,Sensor4,Sensor5,Total
for file in $(find $1 -name "sensordata-*.log")
do
	awk 'BEGIN { c1=0; c2=0; c3=0; c4=0; c5=0 } 
	{
		if ($5=="ERROR") c1++
		if ($6=="ERROR") c2++
		if ($7=="ERROR") c3++
		if ($8=="ERROR") c4++
		if ($9=="ERROR") c5++
	} END {OFS=","; gsub("-", ",", $1); print $1, c1, c2, c3, c4, c5, c1+c2+c3+c4+c5 }' $file
#Use the command "sort" to Sort files and content.
done | sort
echo ====================================
